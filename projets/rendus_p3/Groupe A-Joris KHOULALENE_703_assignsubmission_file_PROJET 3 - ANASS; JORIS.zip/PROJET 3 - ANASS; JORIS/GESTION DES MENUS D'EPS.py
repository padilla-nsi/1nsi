#Les menus proposés
menu_1 = [Foot, Athlétisme, Musculation]
menu_2 = [Basket, Handball, Musculation]
menu_3 = [VolleyBall, Tennis, Musculation]

#Les classes avec les élèves
term_1 = [élève1, élève2, élève3, élève4, élève5, élève6, élève7, élève8, élève9, élève10, élève11, élève12, élève13, élève14, élève15, élève16, élève17, élève18, élève19, élève20, élève21, élève22, élève23, élève24, élève25]
term_2 = [élève1, élève2, élève3, élève4, élève5, élève6, élève7, élève8, élève9, élève10, élève11, élève12, élève13, élève14, élève15, élève16, élève17, élève18, élève19, élève20, élève21, élève22, élève23, élève24, élève25]
term_3 = [élève1, élève2, élève3, élève4, élève5, élève6, élève7, élève8, élève9, élève10, élève11, élève12, élève13, élève14, élève15, élève16, élève17, élève18, élève19, élève20, élève21, élève22, élève23, élève24, élève25]

#Cette fonction permet de saisir les voeux des élèves de Terminale 1
def saisir_voeux():
    tab = [0]*25
    for i in range(25):
        n = int(input("Saisir les choix des élèves de Terminale_1 :"))
        tab[i] = n
    return tab

voeux_term1 = saisir_voeux()

#Cette fonction permet de saisir les voeux des élèves de Terminale 2
def saisir_voeux():
    tab = [0]*25
    for i in range(25):
        n = int(input("Saisir les choix des élèves de Terminale_2 :"))
        tab[i] = n
    return tab

voeux_term2 = saisir_voeux()

#Cette fonction permet de saisir les voeux des élèves de Terminale 3
def saisir_voeux():
    tab = [0]*25
    for i in range(25):
        n = int(input("Saisir les choix des élèves de Terminale_3 :"))
        tab[i] = n
    return tab

voeux_term3 = saisir_voeux()

"""""""""""""""""""""""""""""""""""""""""""""""""""""""""
# générer la liste des élèves/classes du menu 1
def repartir_eleve():
    for i in range(25):
        if voeux_term1[i] == 1:
            term_1[i] == m1[i]
m1 = repartir_eleve(1)
m2 = repartir_eleve(2)
m3 = repartir_eleve(3)

# m1 = term_1[4], term_2[0], term_2[3], term_3[1]]
# init
#m1 = [0] * 25

#m1[0] = term_1[1]
#print(m1)

"""""""""""""""""""""""""""""""""""""""""""""""""""""""""
